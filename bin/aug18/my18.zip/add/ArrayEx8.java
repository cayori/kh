package aug18.add;

public class ArrayEx8 {
	public static void main(String[] args) {
		String src = "ABCDE";
		
		for(int i=0; i<src.length(); i++) {
			System.out.println(i+" 번째 글자 : "+src.charAt(i));
		} // end for i
	}
}